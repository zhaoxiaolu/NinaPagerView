//
//  ForthCollectionView.h
//  NinaPagerView
//
//  Created by RamWire on 16/6/22.
//  Copyright © 2016年 赵富阳. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ForthCollectionView : UICollectionView<UICollectionViewDelegateFlowLayout,UICollectionViewDataSource>

@end
