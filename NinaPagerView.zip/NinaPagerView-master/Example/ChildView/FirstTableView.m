//
//  FirstTableView.m
//  NinaPagerView
//
//  Created by RamWire on 16/5/10.
//  Copyright © 2016年 RamWire. All rights reserved.
//

#import "FirstTableView.h"

@implementation FirstTableView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
