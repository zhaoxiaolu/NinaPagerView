//
//  SecondTableView.h
//  NinaPagerView
//
//  Created by RamWire on 16/5/10.
//  Copyright © 2016年 RamWire. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondTableView : UITableView

@end
