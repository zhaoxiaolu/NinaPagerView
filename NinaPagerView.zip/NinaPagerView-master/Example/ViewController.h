//
//  ViewController.h
//  NinaPagerView
//
//  Created by RamWire on 15/11/13.
//  Copyright © 2015年 RamWire. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

