//
//  SeventhViewController.m
//  NinaPagerView
//
//  Created by RamWire on 16/3/23.
//  Copyright © 2016年 RamWire. All rights reserved.
//

#import "SeventhViewController.h"

@interface SeventhViewController ()

@end

@implementation SeventhViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor cyanColor];
//    [self createLabel:@"7"];
    [self createTableViewFromVC:@"7"];
}

@end
