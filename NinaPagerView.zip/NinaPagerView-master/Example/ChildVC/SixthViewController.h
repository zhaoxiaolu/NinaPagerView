//
//  SixthViewController.h
//  NinaPagerView
//
//  Created by RamWire on 16/3/23.
//  Copyright © 2016年 RamWire. All rights reserved.
//

#import "ChildBaseViewController.h"

@interface SixthViewController : ChildBaseViewController

@end
