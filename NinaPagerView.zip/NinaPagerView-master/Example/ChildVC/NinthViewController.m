//
//  NinthViewController.m
//  NinaPagerView
//
//  Created by RamWire on 16/3/23.
//  Copyright © 2016年 RamWire. All rights reserved.
//

#import "NinthViewController.h"

@interface NinthViewController ()

@end

@implementation NinthViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor brownColor];
//    [self createLabel:@"9"];
    [self createTableViewFromVC:@"9"];
}

@end
