//
//  NinaPagerViewCarthage.h
//  NinaPagerViewCarthage
//
//  Created by RamWire on 16/4/14.
//  Copyright © 2016年 RamWire. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NinaPagerView.h"
#import "UIParameter.h"
#import "NinaBaseView.h"
#import "UIView+ViewController.h"

//! Project version number for NinaPagerViewCarthage.
FOUNDATION_EXPORT double NinaPagerViewCarthageVersionNumber;

//! Project version string for NinaPagerViewCarthage.
FOUNDATION_EXPORT const unsigned char NinaPagerViewCarthageVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NinaPagerViewCarthage/PublicHeader.h>


